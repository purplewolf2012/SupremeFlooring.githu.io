# Supreme Flooring & Construction LLC — Free Website (GitHub Pages)

This is a lightweight static website you can host for **free** on GitHub Pages.

## What’s included
- Home, Services, Gallery, Contact
- Click-to-call and click-to-text buttons
- Mobile menu
- Gallery with filters + lightbox
- Contact form ready for Formspree (free)

## Quick start (publish free)
1. Create a GitHub account (if you don’t have one)
2. Create a new repository named: `<your-username>.github.io`
3. Upload **everything in this folder** to the repository root
4. Go to **Settings → Pages**
   - Source: Deploy from a branch
   - Branch: `main` / root
5. Your site will be live at: `https://<your-username>.github.io`

## Add your photos
- Put images in `assets/gallery/`
- Edit `assets/gallery.json` to add items and tags:
  - tags: `epoxy`, `tile`, `lvp`, `remodel`

## Make the contact form work
This site uses Formspree. Replace this in:
- `index.html` and `contact.html`

`https://formspree.io/f/your-form-id`

with your real Formspree form endpoint.

## Update business info
Phone number is currently: 469-379-0799
Service area: Dallas–Fort Worth & surrounding areas

If you want, tell me:
- your email
- your exact service cities
- your logo file
and I’ll update the site.
